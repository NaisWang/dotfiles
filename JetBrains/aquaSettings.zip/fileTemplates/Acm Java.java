import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class ${NAME} {

	static class Solution {

		class Reader {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringTokenizer tokenizer = new StringTokenizer("");

			String nextLine() {
				String ans = null;
				try {
					ans = br.readLine();
				} catch (Exception e) {
					e.printStackTrace();
				}
				return ans;
			}

			String next() {
				try {
					while (!tokenizer.hasMoreTokens()) {
						tokenizer = new StringTokenizer(br.readLine());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return tokenizer.nextToken();
			}

			int nextInt() {
				return Integer.parseInt(next());
			}

			double nextDouble() {
				return Double.parseDouble(next());
			}

			long nextLong() {
				return Long.parseLong(next());
			}
		}

		final Reader cin = new Reader();

		private Object getDataByScanner(Class a) {
			if (a.equals(Integer.class)) {
				return cin.nextInt();
			} else if (a.equals(Double.class)) {
				return cin.nextDouble();
			} else if (a.equals(Long.class)) {
				return cin.nextLong();
			} else if (a.equals(String.class)) {
				return cin.nextLine();
			} else {
				throw new RuntimeException("输入的数据类型不支持!!!");
			}
		}

		void read(Object o) {
			Class eClass = o.getClass();
			if (eClass == int[].class) {
				int[] b = (int[]) o;
				for (int i1 = 0; i1 < b.length; i1++) {
					b[i1] = (Integer) getDataByScanner(Integer.class);
				}
			} else if (eClass == long[].class) {
				long[] b = (long[]) o;
				for (int i1 = 0; i1 < b.length; i1++) {
					b[i1] = (Long) getDataByScanner(Long.class);
				}
			} else if (eClass == float[].class) {
				float[] b = (float[]) o;
				for (int i1 = 0; i1 < b.length; i1++) {
					b[i1] = (Float) getDataByScanner(Float.class);
				}
			} else if (eClass == double[].class) {
				double[] b = (double[]) o;
				for (int i1 = 0; i1 < b.length; i1++) {
					b[i1] = (Double) getDataByScanner(Double.class);
				}
			} else {
                throw new RuntimeException("输入的数据类型不支持!!!");
			}
		}

		void read(Object[] a) {
			for (int i = 0; i < a.length; i++) {
				Object o = a[i];
				if (o == null || !o.getClass().isArray()) {
					a[i] = getDataByScanner(a.getClass().getComponentType());
					continue;
				}
				Class eClass = o.getClass();
				if (Arrays.asList(int[].class, long[].class, double[].class).contains(eClass)) {
					read(o);
				} else {
					read((Object[]) o);
				}
			}
		}

		String getString(Object a) {
			Class eClass = a.getClass();
			String ans = "";
			if (eClass == byte[].class) {
				ans = Arrays.toString((byte[]) a);
			} else if (eClass == short[].class) {
				ans = Arrays.toString((short[]) a);
			} else if (eClass == int[].class) {
				ans = Arrays.toString((int[]) a);
			} else if (eClass == long[].class) {
				ans = Arrays.toString((long[]) a);
			} else if (eClass == char[].class) {
				ans = Arrays.toString((char[]) a);
			} else if (eClass == float[].class) {
				ans = Arrays.toString((float[]) a);
			} else if (eClass == double[].class) {
				ans = Arrays.toString((double[]) a);
			} else if (eClass == boolean[].class) {
				ans = Arrays.toString((boolean[]) a);
			}
			return ans;
		}

		void toPithy(String a) {
			a = a.replace("[[", "").replace("]]", "").replace(" [", "");
			String[] items = a.split("],");
			for (String item : items) {
				System.out.println(item.replace(",", "").replace("[", "").replace("]", ""));
			}
		}

		void println(Object[] a) {
			System.out.println(Arrays.deepToString(a));
		}

		void println(Object a) {
			System.out.println(getString(a));
		}


		void printlnPithy(Object[] a) {
			toPithy(Arrays.deepToString(a));
		}

		void printlnPithy(Object a) {
			toPithy(getString(a));
		}

		public void solve() {

		}

	}

	public static void main(String[] args) {
		Solution solution = new Solution();
		solution.solve();
	}
}
